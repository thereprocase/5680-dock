"""R4 quick-fit bracket pair: R2 contact + the V5 3.5-mm lid-rail move + beef.

Run with CadQuery, trimesh, NumPy and Pillow (`cadpy build_quick_fit.py --variant B`).
Outputs beside this script. The heel extension is re-extracted from the original
visualization mesh exactly as R2 does.

Variant selects the seat side, matching the V5 coupon letters:
  A  original R1 seat and lip (no R2 outward lip shift, rise or heel extension)
  B  R2 seat, lip shift, lip rise and heel extension (default)
  C  B plus the 1-mm local seat relief band under the R2 curve
All variants move the whole lid-rail side 3.5 mm outward (unleaned +Y), as the
printed V5 coupons do, and thicken the load-carrying members outward/downward so
the laptop-facing surfaces are unchanged: rail 4 -> 6 mm, short fence +2 mm on
its outer face, base plate 4 -> 6 mm, diagonal brace 4 -> 6 mm.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys

import cadquery as cq
import numpy as np
import trimesh
from PIL import Image, ImageDraw

R = Path(__file__).resolve().parent
D = R.parents[1]
R2 = R.parent / 'R2'
sys.path.insert(0, str(D))
from raster import render, font

parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument('--variant', choices=('A', 'B', 'C'), default='B')
args = parser.parse_args()
VARIANT = args.variant

P = json.loads((D/'parameters.json').read_text(encoding='utf-8'))
C = json.loads((D/'contact-profiles.json').read_text(encoding='utf-8'))
G = json.loads((D/'geometry.json').read_text(encoding='utf-8'))
F = json.loads((R/'fit-parameters.json').read_text(encoding='utf-8'))
H, T, W = P['rear_case_seat_z'], P['laptop_thickness'], P['laptop_width']
B = 38.1
A = math.radians(P['laptop_lean_deg'])
S = F['rail_outward_shift_mm']          # 3.5, the V5 move
RT = F['rail_thickness_mm']             # 6 (was 4)
FE = F['fence_extra_outer_thickness_mm']  # 2
BT = F['base_thickness_mm']             # 6 (was 4)
BW = F['brace_width_mm']                # 6 (was 4)
items = [p for p in G['parts'] if p['name'].startswith(('01_', '02_', 'bridge_key')) and '_desk_pad_' not in p['name']]
lo = [min(p['bounds_mm'][i] for p in items) for i in range(3)]
hi = [max(p['bounds_mm'][i+3] for p in items) for i in range(3)]
y0, y1 = lo[1], hi[1]
xstarts = [lo[0], hi[0]-B]
gap = xstarts[1]-xstarts[0]-B


def poly(points, width=B, x=0):
    return cq.Workplane('YZ', origin=(x, 0, 0)).polyline(points).close().extrude(width).val()


def box(y, z, dy, dz):
    return poly([(y,z), (y+dy,z), (y+dy,z+dz), (y,z+dz)])


def lean(shape):
    return shape.rotate((0,0,H), (1,0,H), -P['laptop_lean_deg'])


def solid_box(x, y, z, dx, dy, dz):
    return cq.Workplane('XY').box(dx, dy, dz, centered=False).translate((x,y,z))


# Identical contact extraction to R2: original samples plus the re-extracted heel.
old_curve = [(a[0], H+min(c['rear_curve_local_yz_mm'][j][1] for c in C['curves']))
             for j,a in enumerate(C['curves'][0]['rear_curve_local_yz_mm'])]
source = D.parent/'history/reference-assets/laptop.glb'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash == C['source_sha256'], 'Reference source changed'
scene = trimesh.load(source)
transform, geometry = scene.graph[C['case_node']]
case = scene.geometry[geometry].copy()
case.apply_transform(transform)
case.apply_scale(1000)
rear = case.bounds[0,2]


def section_values(x, ys):
    segments = trimesh.intersections.mesh_plane(case, [1,0,0], [x,0,0])
    values = []
    for local_y in ys:
        hits = []
        for a,b in segments:
            if abs(b[1]-a[1]) < 1e-9:
                continue
            f = (local_y+T/2-a[1])/(b[1]-a[1])
            if 0 <= f <= 1:
                hits.append(float(a[2]+f*(b[2]-a[2])-rear+H))
        values.append(min(hits) if hits else None)
    return values


extra = F['seat_extension_toward_underside_mm']
extra_ys = np.arange(old_curve[0][0]-extra, old_curve[0][0]-.001, .2)
sections = [section_values(c['case_x_from_center_mm'], extra_ys) for c in C['curves']]
extension = [(float(y), min(s[j] for s in sections if s[j] is not None)) for j,y in enumerate(extra_ys)]
curve = extension+old_curve
assert all(z >= H for y,z in curve)
r2_profile = json.loads((R2/'seat-profile.json').read_text(encoding='utf-8'))
assert all(abs(a-b[0]) < 1e-9 and abs(z-b[1]) < 1e-9 for (a,z),b in zip(curve, r2_profile['revised_yz_mm'])), 'R2 seat profile not reproduced'


def bracket(variant):
    revised = variant in ('B', 'C')
    offset = F['lip_outward_shift_mm'] if revised else 0
    rise = F['lip_height_increase_mm'] if revised else 0
    seat_curve = curve if revised else old_curve
    s = box(y0,-1-BT,y1-y0,BT).fuse(box(-6,-2,12,53))
    s = s.fuse(lean(box(-15-offset-FE,46,32+offset+FE+S,5)))
    s = s.fuse(lean(poly([(seat_curve[0][0],49),(seat_curve[-1][0],49)]+list(reversed(seat_curve)))))
    outer, tip, inner = -T/2-3-offset-FE, -T/2-1-offset, -T/2-.25-offset
    top, shoulder = 66+rise, 62+rise
    lip = poly([(outer,47),(outer,top),(tip,top),(inner,shoulder),(inner,47)])
    if revised:
        edges = [e for e in lip.Edges() if e.BoundingBox().xlen > B-.01
                 and abs(e.Center().z-top) < .001]
        assert len(edges) == 2
        lip = lip.fillet(F['lip_top_edge_radius_mm'], edges)
    s = s.fuse(lean(lip))
    s = s.fuse(lean(box(T/2+S,48,RT,86)))
    top_y = (T/2+S+RT/2)*math.cos(A)+(134-H)*math.sin(A)
    s = s.fuse(poly([(top_y-BW/4,129),(top_y+3*BW/4,134),(y1-1,-1),(y1-1-BW-2,-1)]))
    s = s.fuse(box(top_y+RT/2-1,131,3,hi[2]-131)).clean()
    if variant == 'C':
        original = [(float(y), float(z)) for y, z in r2_profile['revised_yz_mm']]
        lowered = [(y, z-1.0) for y, z in reversed(original)]
        s = s.cut(lean(poly(original+lowered))).clean()
    label = f'R4-{variant} GAP {gap:.2f} mm'
    s = s.cut(cq.Workplane('YZ',origin=(B-.5,43,-3)).text(label,2.4,.6,font='Arial',combine=False).val()).clean()
    assert s.isValid() and len(s.Solids()) == 1
    return s


s = bracket(VARIANT)

# Rail-position receipts: the new inner face sits at T/2+S like the V5 coupons,
# and the 3.5-mm channel between the old and new faces is empty above the deck.
probe_new_face = lean(box(T/2+S, 52, .1, 80))
probe_channel = lean(box(T/2, 51.001, S, 83))
assert abs(probe_new_face.intersect(s).Volume() - B*.1*80) < 1e-3
assert probe_channel.intersect(s).Volume() < 1e-6

# Same nominal D8 envelope and heel cut as R2, with the same contact checks.
laptop = solid_box(0,-T/2,H,W,T,P['laptop_depth']).edges('|Y').fillet(4)
laptop = laptop.cut(solid_box(30,-7,H-1,W-60,17,5))
heel = [(curve[0][0],H-6),(curve[-1][0],H-6)]+list(reversed(curve))
for x, width in [(0,30),(W-30,30)]:
    laptop = laptop.cut(poly(heel,width,x))
laptop = lean(laptop.val())
feet = []
keepouts = []
for f in C['rubber_feet']:
    a,b = f['untilted_case_relative_bounds_mm']
    feet.append(lean(solid_box(a[0],a[1],H+a[2],b[0]-a[0],b[1]-a[1],b[2]-a[2]).val()))
    keepouts.append(lean(solid_box(a[0]-2,a[1]-2,H+a[2]-2,b[0]-a[0]+4,b[1]-a[1]+4,b[2]-a[2]+4).val()))
placed = [s.translate((x,0,0)) for x in xstarts]
checks = []
motion = []
for i,q in enumerate(placed):
    checks.append(dict(laptop_overlap_mm3=q.intersect(laptop).Volume(),
        rubber_foot_overlap_mm3=sum(q.intersect(f).Volume() for f in feet),
        expanded_foot_keepout_overlap_mm3=sum(q.intersect(f).Volume() for f in keepouts),
        seat_contact_probe_mm3=q.translate((0,.02*math.sin(A),.02*math.cos(A))).intersect(laptop).Volume()))
    for lift in [0,.25,.5,1,2,3,5,10,20,40]:
        delta = (0,lift*math.sin(A),lift*math.cos(A))
        motion.append(dict(bracket=i+1,lift_mm=lift,
            laptop_overlap_mm3=q.intersect(laptop.translate(delta)).Volume(),
            foot_keepout_overlap_mm3=sum(q.intersect(f.translate(delta)).Volume() for f in keepouts)))
if VARIANT != 'C':
    assert all(c['seat_contact_probe_mm3']>.01 for c in checks), checks
assert all(c['laptop_overlap_mm3']<.001 and c['rubber_foot_overlap_mm3']<.001
           and c['expanded_foot_keepout_overlap_mm3']<.001 for c in checks), checks
assert all(c['laptop_overlap_mm3']<.001 and c['foot_keepout_overlap_mm3']<.001 for c in motion), motion

# Lid-side clearance: the nominal lid top (y=+T/2) now clears the rail by S.
lid_probe = lean(solid_box(xstarts[0], T/2, H+2, B, S-.05, 70).val())
assert lid_probe.intersect(placed[0]).Volume() < 1e-6

printed = s.rotate((0,0,0),(0,1,0),-90)
b = printed.BoundingBox()
printed = printed.translate((-b.xmin,-b.ymin,-b.zmin))
stl = R/f'D8-R4-{VARIANT}-quick-fit-bracket-print-TWO.stl'
step = R/f'D8-R4-{VARIANT}-quick-fit-bracket.step'
cq.exporters.export(printed,str(stl),tolerance=.04,angularTolerance=.1)
cq.exporters.export(s,str(step))
mesh = trimesh.load_mesh(stl)
assert mesh.is_watertight and mesh.is_winding_consistent and len(mesh.split())==1
assert mesh.volume>0 and max(mesh.extents[:2])+16 < 256 and mesh.extents[2]<256
roundtrip = cq.importers.importStep(str(step)).val()
assert roundtrip.isValid() and len(roundtrip.Solids())==1
assert abs(roundtrip.Volume()-s.Volume())<.001

report = dict(passed=True,revision=f'R4-{VARIANT} fit pair',quantity=2,identical=True,
    variant=VARIANT,changes=F,
    rail_inner_face_unleaned_y_mm=T/2+S,rail_thickness_mm=RT,
    lip_nominal_clearance_mm=(.25+F['lip_outward_shift_mm']) if VARIANT!='A' else .25,
    fence_inner_to_rail_inner_mm=T+.25+(F['lip_outward_shift_mm'] if VARIANT!='A' else 0)+S,
    base_thickness_mm=BT,brace_width_mm=BW,
    seat_datum_unchanged=True,bracket_width_mm=B,
    inside_clear_gap_mm=gap,center_spacing_mm=xstarts[1]-xstarts[0],
    outside_width_mm=hi[0]-lo[0],footprint_depth_mm=y1-y0,
    height_above_desk_mm=hi[2]+1+BT,nominal_lean_degrees=P['laptop_lean_deg'],
    solid_volume_each_cm3=s.Volume()/1000,
    solid_PETG_mass_pair_g=s.Volume()/1000*1.27*2,
    print_bounds_mm=mesh.extents.tolist(),mesh_watertight=bool(mesh.is_watertight),
    mesh_connected_components=len(mesh.split()),step_roundtrip_valid=True,
    checks=checks,motion=motion,
    cadquery_version=cq.__version__,trimesh_version=trimesh.__version__,
    source_mesh_sha256=source_hash,
    input_sha256={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in [Path(__file__),R/'fit-parameters.json',R2/'seat-profile.json',D/'parameters.json',D/'contact-profiles.json',D/'geometry.json']},
    output_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [stl,step]},
    scope='Loaded fit prototype: R2 contact, V5 rail offset, thicker members. Source visualization mesh and nominal CAD checks only; physical fit, stability and strength untested.')
(R/f'checks-{VARIANT}.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

im,_ = render([(q,(62,117,139)) for q in placed]+[(laptop,(188,195,198))],(1500,950),(.8,-1,.65),pad=65)
canvas = Image.new('RGB',(1500,1070),'#f7f7f7'); canvas.paste(im,(0,75)); draw=ImageDraw.Draw(canvas)
draw.text((35,20),f'D8 R4-{VARIANT} fit pair | Print the same bracket twice',font=font(29,True),fill='#20313c')
draw.text((35,1020),f'Inside gap {gap:.2f} mm | Lid rail moved {S} mm outward | Rail {RT} mm, base {BT} mm, brace {BW} mm',font=font(23),fill='#20313c')
canvas.save(R/f'D8-R4-{VARIANT}-quick-fit.png')
im,_=render([(s,(62,117,139))],(1100,900),(1,-.15,.13),pad=60)
im.save(R/f'D8-R4-{VARIANT}-quick-fit-profile.png')
print(json.dumps({k:v for k,v in report.items() if k not in ('motion','checks','input_sha256','output_sha256','changes')}),flush=True)
