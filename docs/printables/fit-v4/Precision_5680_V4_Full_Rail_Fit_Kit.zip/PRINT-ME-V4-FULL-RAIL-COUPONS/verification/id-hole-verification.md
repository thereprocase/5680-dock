# V4 identifier receipt

Independent Terra-Verification check, reviewed by Dock-Architect-Astra:
all six 2-mm-square CAD holes retain a1-mm square road-clear core and actual
surrounding walls on all120 model layers. Original0.35-mm wall-edge proximity
criterion retained; G0/G1/G2/G3 and recorded road widths included. Exact JSON
and close-up image are supplied. Raw motion is converted with the frozen
(0,+2)-mm nozzle offset. This is a slicer-coordinate result; no physical hole
size or printed fit is measured. See verification-coordinate-correction.md
for superseded earlier coordinate comparisons.
