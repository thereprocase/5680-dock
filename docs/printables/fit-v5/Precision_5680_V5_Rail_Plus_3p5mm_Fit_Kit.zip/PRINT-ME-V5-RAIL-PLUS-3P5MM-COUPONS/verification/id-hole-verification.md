# V5 identifier receipt

Same fail-closed audit as V4 (`audit_v5_id_holes.py`, a path-only copy of the
V4 checker): all six 2-mm-square CAD holes retain a 1-mm square road-clear core
and actual surrounding walls on all 120 model layers. The 0.35-mm wall-edge
proximity criterion is retained; G0/G1/G2/G3 and recorded road widths are
included. Raw motion is converted with the frozen (0,+2)-mm nozzle offset. The
identifier holes did not move between V4 and V5; only the rail side of each
coupon did. This is a slicer-coordinate result; no physical hole size or
printed fit is measured. See verification-coordinate-correction.md for the
superseded earlier coordinate comparisons.
