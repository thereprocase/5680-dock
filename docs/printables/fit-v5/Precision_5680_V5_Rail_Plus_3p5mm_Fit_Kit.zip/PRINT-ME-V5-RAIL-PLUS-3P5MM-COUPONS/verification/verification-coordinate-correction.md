# Correction to earlier identifier toolpath findings

The frozen machine profile and G-code declare `extruder_offset = 0x2`.
CAD and native 3MF use plate coordinates; emitted motion coordinates subtract
the single nozzle's configured (0,+2)-mm offset. The identifier checker initially
compared the two frames directly. That was an audit error, not evidence of
filled holes. A separate intermediate V4 checker also confused centered-mesh
3MF translations with its lower bounding coordinates; that error was corrected.

Any earlier V3/V4 assertion that extrusion crossed identifiers based on raw
unadjusted motion must be treated as superseded. The final identifier receipt
in this package is authoritative and includes the exact declared nozzle offset,
the G-code hash, all120 layers, road widths, and a clear core plus wall witnesses.
The geometry and existing slice were not changed to resolve the frame error.

V4 retains larger 2-mm square identifiers as a readability-oriented diagnostic
choice. This does not establish that V3's smaller IDs would fail physically.
The frozen source and pre-slice review receipts preserve their original stage
wording; read their identifier-HOLD rationale with this correction notice.

This is coordinate-consistent slicer verification, not a measurement of a
physical nozzle's calibration, printed fit, or actual opening dimensions.
