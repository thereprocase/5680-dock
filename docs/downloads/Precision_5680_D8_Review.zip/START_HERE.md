# Precision 5680 D8 print and source package

This archive contains all 43 manufacturing STLs, editable D8 source, renders,
design notes and the recorded CAD/manufacturing checks.

The complete STEP CAD is a separate download:
https://thereprocase.github.io/5680-dock/downloads/Precision_5680_D8_STEP.zip
Extract that archive into desk-dock/D8 if you want the STEP beside these files.

Start with desk-dock/D8/README.md and CURRENT_STATUS.md. Use the full GitHub
repository for historical references and the web viewer. This package contains
no approved P1S G-code; physical fit and strength still need qualification.

Current source and interactive model:
https://github.com/thereprocase/5680-dock
https://thereprocase.github.io/5680-dock/desk-dock.html
