# D7 — recessed fans and hand assembly

The plenum carries the laptop and encloses the fan frames. Each removable guard
also retains its fan. Bottom panels open the ducts for cleaning and support
removal; two small bridges join the printed halves. A continuous low lip restrains the laptop along its underside edge; the loading end stays open.

Target: **PETG, Bambu P1S, 0.4 mm nozzle**. This is a prototype CAD package with
print-oriented meshes. Orca crashed during startup and the installed Bambu
fallback also failed CLI discovery, so **no toolpaths have been generated or
approved**. Neither application was retried after its failed discovery.

- [Interactive local viewer](http://127.0.0.1:8768/docs/desk-dock.html)
- [Design review and assembly guide](REVIEW.md)
- [Print preparation and results](PRINT_PREPARATION.md)
- [Connector assembly and calibration](CASSETTE_ASSEMBLY.md)
- [STEP assembly](Precision_5680_D7.step)
- [Individual PETG parts and fit samples](print/)

The retention lip now spans 367.68 mm, interrupted only by the existing 0.30 mm shell joint. It keeps the original 12 mm height above the seat and clears the expanded rear-foot envelope by 3.06 mm. The rear exhaust liner adheres directly to its inside face.

## Geometry

| Item | D7 |
| --- | --- |
| Stand width, including plug station | 418.68 mm |
| Stand depth, including hand controls | 121.16 mm |
| Laptop lean | 5 degrees |
| Fan discharge | 18 degrees above the desk |
| Fans | Two 120 × 120 × 15 mm reference envelopes |
| Fan top suction face to lid | 14.78 mm normal distance |
| Minimum sampled inlet clearance | 12.5 mm |
| Conservative connected cavity volume | 1.784 litres total |
| PETG components | 19 individual parts, plus fit samples |
| Largest print pose | 216.84 × 140.57 × 114.01 mm |

The service hardware increases depth by 6.01 mm over compact D6. Recessing the
frames encloses their edges while keeping the fan position fixed. The new bosses
reduce the conservative cavity volume by about 2%; the measured CAD clearance
screen remains unchanged. Airflow, temperature and sound still need a prototype;
the calculation does not establish an operating flow rate.

Both Thunderbolt ports remain on the Precision 5680's keyboard-left edge, at
the plug station. That edge appears on the right when looking at the lid.
The [source port study](../D6/PORT_STUDY.md) and D7 port probes preserve this
orientation.

## Hand assembly

1. Fit the metal nuts with each shell open. Join the two halves using the two
   deck bridges and their four hand screws.
2. Fit the bottom-panel gasket strips and eight adhesive desk pads. Install
   each bottom panel with two recessed hand screws. Pads attach to the panels,
   clear of their screw-access wells.
3. Seat each fan in its pocket and on its two locating pegs, with discharge
   facing outward/upward. Fit the guard and its two hand knobs. The M3 fan nuts
   use enclosed side-entry traps; they cannot fall backward into the duct.
4. Apply the soft end seats, lid liners and exhaust seals. These are compliant
   purchased/cut materials, not rigid PETG prints.
5. Assemble the cassette, fit the original plug and thin metal capture clip,
   slide its cap toward the laptop and lock its quarter-turn keeper. Calibrate
   the three adjustments on the actual machine, then set the independent
   chassis stop. See the detailed cassette guide.

Unload the laptop before service. Withdraw it 18 mm away from the plug, then
lift along its lean. Fan guards and fans remove from the front. Bottom panels
remove downward with their desk pads attached. The cap keeper is retained
while locked and removable while unlocked.

The hardware allowance is fourteen M3 screw/nut pairs, one M4 stop screw/nut,
two M3 cassette washers and the 0.8 mm capture clip. Four fan screws have a
30 mm shaft envelope. Bottom, bridge and cassette screw envelopes are 7, 14
and 18 mm respectively; choose actual stock lengths and spacing washers for
full nut engagement without bottoming out. Hand-head dimensions and the actual
fan/cable must be fitted before printing the full dock. Metal threads carry
the fastening loads; printed controls provide the hand grip.

## Verification

`validation.json` records 93 valid STEP solids, no nominal rigid-part
intersections, all three port probes and twelve clear docking poses including
expanded laptop-foot keepouts. `service-validation.json` records nine clear
sampled service stages and five isolated cassette settings. The separate
bearing-contact and airflow screens are in `alignment-validation.json` and
`airflow-sizing.json`.

Print the fit samples first. The two shells sit fan-pocket-face down, with a
planar rim supporting the first layer. The open soles give access for support
removal; they do not make the shells support-free. PETG fit, support removal,
retention, warm creep, desk stability and actual cooling remain physical checks.

![D7 assembled](D7-assembled.png)
![Recessed fan frames with guards removed](D7-fan-pockets.png)

![Continuous low retention lip](D7-continuous-lip.png)
