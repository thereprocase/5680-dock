"""Render the exact D7 CAD, without a mirrored projection."""
from pathlib import Path
import build
from raster import render
R=Path(__file__).resolve().parent
objects=[(a['shape'],a['color']) for a in build.parts]
img,_=render(objects,(1500,1080),(-.55,1,.55),pad=45)
img.save(R/'D7-assembled.png')
objects=[(a['shape'],a['color']) for a in build.parts if a['name']!='Precision_5680_REFERENCE' and not a['name'].startswith('RUBBER_FOOT_') and not any(k in a['name'] for k in ['fan_guard','fan_thumb_lock','fan_M3_screw'])]
img,_=render(objects,(1500,850),(-.15,1,.28),pad=45)
img.save(R/'D7-fan-pockets.png')
img,_=render(objects,(1500,850),(.15,-1,.45),pad=45)
img.save(R/'D7-continuous-lip.png')
print('CAD review images saved',flush=True)
