"""Sampled D7 assembly/service clearances; no claim of physical qualification.

Run from any working directory. Importing build regenerates the final assembly
once; every service sample then reuses those shapes. Adjustment corner checks
regenerate only the small isolated connector cassette, never the entire dock.
"""
import itertools
import json
import math
from pathlib import Path

import cadquery as cq
import build
from cassette import build_cassette

R=Path(__file__).resolve().parent
LIMIT=.01


def overlap(a,b):
    A=a.BoundingBox(); B=b.BoundingBox()
    if (A.xmax<=B.xmin+1e-6 or B.xmax<=A.xmin+1e-6 or
        A.ymax<=B.ymin+1e-6 or B.ymax<=A.ymin+1e-6 or
        A.zmax<=B.zmin+1e-6 or B.zmax<=A.zmin+1e-6):
        return 0.0
    return a.intersect(b).Volume()


def cassette_corner(dx,dy,dz):
    parts=[]
    def add(name,shape,color=None,ref=False):
        if isinstance(shape,cq.Workplane): shape=shape.val()
        assert shape.isValid() and len(shape.Solids())==1 and shape.Volume()>0,name
        parts.append(dict(name=name,shape=shape,reference=ref))
    p=dict(build.p,depth_adjustment=dx,lateral_adjustment=dy,height_adjustment=dz)
    build_cassette(p,build.box,build.rb,build.hole,add)
    hits=[]
    for a,b in itertools.combinations(parts,2):
        # Metal thread envelopes intentionally overlap their metal nuts.
        if a['reference'] and b['reference']: continue
        v=overlap(a['shape'],b['shape'])
        if v>LIMIT: hits.append([a['name'],b['name'],round(v,6)])
    return dict(adjustment_depth_lateral_height_mm=[dx,dy,dz],
                valid_single_solids=len(parts),collisions=hits,
                scope='Isolated cassette only; not a laptop/plenum adjustment qualification.')


def main():
    byname={a['name']:a for a in build.parts}
    unloaded={n for n in byname if n=='Precision_5680_REFERENCE' or n.startswith('RUBBER_FOOT_')}
    stages=[]

    def stage(label,moving,removed,samples,transform,operation):
        moving=set(moving); removed=set(removed)|unloaded
        assert moving and all(n in byname for n in moving),(label,moving)
        fixed=[a for n,a in byname.items() if n not in moving|removed]
        rows=[]
        for sample in samples:
            hits=[]
            for name in sorted(moving):
                moved=transform(byname[name]['shape'],sample)
                for a in fixed:
                    v=overlap(moved,a['shape'])
                    if v>LIMIT: hits.append([name,a['name'],round(v,6)])
            rows.append(dict(sample=sample,collisions=hits))
        result=dict(operation=label,instruction=operation,moving_parts=sorted(moving),
                    removed_before_operation=sorted(removed),samples=rows,
                    passed=all(not row['collisions'] for row in rows))
        stages.append(result)
        print(label+': '+('PASS' if result['passed'] else 'COLLISION'),flush=True)

    lean=math.radians(build.LEAN)
    lean_axis=(0,math.sin(lean),math.cos(lean))
    kx=-24.7+build.p['depth_adjustment']
    ky=build.p['port_y']+build.p['lateral_adjustment']+7.5
    origin=(kx,ky*math.cos(lean),build.H-ky*math.sin(lean))
    endpoint=tuple(a+b for a,b in zip(origin,lean_axis))
    keeper='plug_cap_quarter_turn_keeper'; cap='sliding_plug_cap'
    stage('Cassette keeper unlock',[keeper],[],[0,30,60,90],
          lambda s,a:s.rotate(origin,endpoint,a),
          'Rotate the rigid keeper 90 degrees about its leaned shaft; laptop removed.')
    stage('Cassette keeper withdrawal',[keeper],[],[0,1,3,6,10,15],
          lambda s,d:s.rotate(origin,endpoint,90).translate(tuple(d*v for v in lean_axis)),
          'After unlocking, pull the keeper along its shaft. Keeper becomes removable.')
    stage('Cassette cap withdrawal',[cap],[keeper],[0,1,5,15,30],
          lambda s,d:s.translate((-d,0,0)),
          'Remove keeper, then slide the cap toward the cable along -X.')

    fan_axis=(0,math.cos(build.ELEV),math.sin(build.ELEV))
    for prefix in ['01_','02_']:
        panel=prefix+'bottom_panel'
        feet={n for n in byname if n.startswith(prefix+'foot_')}
        locks={n for n in byname if n.startswith(prefix+'bottom_thumb_lock_')}
        stage(prefix+'bottom panel withdrawal',{panel}|feet,locks,[0,.5,2,5,10,20],
              lambda s,d:s.translate((0,0,-d)),
              'Lift the unloaded stand clear of desk, remove both bottom hand screws, '
              'then lower this panel with its attached soft feet. Nuts remain in the shell.')

        guard=prefix+'fan_guard_retainer'
        fasteners={n for n in byname if n.startswith((prefix+'fan_M3_screw_envelope_',prefix+'fan_thumb_lock_'))}
        stage(prefix+'fan guard withdrawal',[guard],fasteners,[0,1,3,8,16,30,50],
              lambda s,d:s.translate(tuple(d*v for v in fan_axis)),
              'Remove the two hand knobs with their screws, then lift the guard away '
              'along the fan discharge axis. Captured nuts remain in the plenum.')
        fan={n for n in byname if n.startswith(prefix) and
             ('120x15_fan_frame' in n or 'fan_hub_struts' in n or 'blade_' in n)}
        stage(prefix+'fan withdrawal',fan,fasteners|{guard},[0,1,3,8,16,30,50],
              lambda s,d:s.translate(tuple(d*v for v in fan_axis)),
              'After removing guard and screws, unplug fan power and withdraw the '
              'complete fan off the locating pegs along its discharge axis. Cable is not modeled.')

    adjustments=[]
    for dx,dy,dz in [(build.p['depth_adjustment'],build.p['lateral_adjustment'],build.p['height_adjustment']),
                     (-5,-3,-4),(5,3,5),(-5,3,5),(5,-3,-4)]:
        row=cassette_corner(dx,dy,dz)
        adjustments.append(row)
        print('Cassette adjustment '+str([dx,dy,dz])+': '+('PASS' if not row['collisions'] else 'COLLISION'),flush=True)

    data=dict(assembly='Precision_5680_D7',collision_reporting_threshold_mm3=LIMIT,
              source_policy='Final build imported once; service samples reuse final assembled shapes.',
              scope='Sampled nominal rigid geometry, with laptop unloaded before service. '
                    'This is not continuous swept-volume, hand-reach, retention-force, '
                    'thread, tolerance, cable routing, slicer or physical qualification.',
              service_stages=stages,cassette_adjustment_samples=adjustments,
              passed=all(s['passed'] for s in stages) and all(not r['collisions'] for r in adjustments))
    (R/'service-validation.json').write_text(json.dumps(data,indent=2)+'\n')
    assert data['passed'],'See service-validation.json for the colliding sample and part pair.'
    print('D7 sampled service checks passed.',flush=True)


if __name__=='__main__':
    main()
