"""Separate PETG parts in explicit print poses; never slice the assembly."""
import json
from pathlib import Path
import cadquery as cq
import build

R=Path(__file__).resolve().parent
OUT=R/'print'
OUT.mkdir(exist_ok=True)
records=[]
for a in build.parts:
    n=a['name']
    if a['reference'] or any(k in n for k in ['foot_', 'pad_', 'liner_', 'seal_', 'soft_tip']):
        continue
    s=a['shape']
    if 'manifold' in n:
        s=s.rotate((0,0,0),(1,0,0),-build.ANGLE)
        pose='Fan pocket front rim on bed; open sole accessible for support removal.'
    elif 'fan_guard' in n or 'fan_thumb_lock' in n:
        s=s.rotate((0,0,0),(1,0,0),-build.ANGLE)
        pose='Flat front face on bed; fan-facing pads or hex well upward.'
    elif n.startswith(('01_', '02_')) or 'bridge_key' in n:
        pose='Flat underside on bed.'
    else:
        s=s.rotate((0,0,build.H),(1,0,build.H),build.LEAN)
        pose='Laptop lean removed; flat underside on bed.'
        if n=='sliding_plug_cap':
            s=s.rotate((0,0,0),(1,0,0),180)
            pose='Cap top on bed; T rails upward.'
        if n=='plug_cap_quarter_turn_keeper':
            s=s.rotate((0,0,0),(1,0,0),180)
            pose='Thumb paddle face on bed; stem and T lug upward; inspect lug support.'
        if n=='stop_thumb_knob':
            s=s.rotate((0,0,0),(0,1,0),-90)
            pose='Outer hand face on bed; hex head well upward.'
    b=s.BoundingBox()
    s=s.translate((-b.xmin,-b.ymin,-b.zmin))
    b=s.BoundingBox()
    cq.exporters.export(s,str(OUT/(n+'.stl')),tolerance=.08,angularTolerance=.12)
    slab=cq.Workplane('XY').box(b.xlen+2,b.ylen+2,.2,centered=False).translate((-1,-1,0)).val()
    records.append(dict(part=n,file=n+'.stl',orientation=pose,
        dimensions_mm=[b.xlen,b.ylen,b.zlen],first_0p2mm_mean_contact_area_mm2=s.intersect(slab).Volume()/.2,
        support_review='Required: inspect unsupported ledges, bridges and support removal in a working slicer.',
        material='PETG',printer='Bambu P1S, 0.4 mm nozzle'))
(R/'print-manifest.json').write_text(json.dumps(dict(parts=records,scope='Print poses and geometric outputs only. No toolpaths or physical print qualification.'),indent=2)+'\n')
print('Print-oriented parts:',len(records),flush=True)
