"""Open-sole plenum shells, removable floor panels and hand-fastened bridge keys.

Screw threads are represented by their diameters. Captive nuts and actual hand
heads are modeled; use purchased metal thumbscrews with the indicated lengths.
"""
import cadquery as cq

def body_service(bodies,W,front_y,box,rb,hole,add):
    metadata=[]
    def hexshape(x,y,z,diam,h):
        return cq.Workplane('XY',origin=(x,y,z)).polygon(6,diam).extrude(h)
    def nut(name,x,y,z):
        s=hexshape(x,y,z,6.35,2.4).cut(hole((0,0,1),(x,y,z-.1),1.6,2.6))
        add(name,s,(142,150,150),True)
    def thumb(name,x,y,z,length,up=True):
        # 12 mm fluted hand head remains accessible outside the shell.
        head=cq.Workplane('XY',origin=(x,y,z)).circle(6).extrude(4)
        for dx,dy in [(6,0),(-6,0),(0,6),(0,-6)]:
            head=head.cut(hole((0,0,1),(x+dx,y+dy,z-.1),1.1,4.2))
        if up:shaft=hole((0,0,1),(x,y,z+3.9),1.5,length)
        else:shaft=hole((0,0,-1),(x,y,z+.1),1.5,length)
        add(name,head.union(shaft),(86,115,108),True)
    # Bottom panels sit inside the original feet/desk envelope. Thumb heads are
    # recessed into the panel pockets, reached while the unloaded stand is lifted.
    for i,(x0,x1,body) in enumerate(bodies,1):
        front=front_y(5.4)-6
        opening=rb(x0+6,-18,2.9,x1-x0-12,front+18,3.2,3)
        body=body.cut(opening.val())
        plate=rb(x0+2.6,-21.4,.5,x1-x0-5.2,front_y(3)-2.6+21.4,2.3,3)
        tongue=rb(x0+6.35,-17.65,2.8,x1-x0-12.7,front+17.3,2.2,2.65)
        plate=plate.union(tongue)
        # Local button pockets extend upward into otherwise unused floor corners,
        # putting thumb heads above the desk plane. Sealed nut bosses are separate
        # from the bulk air path and accessible from the open sole during setup.
        for j,x in enumerate([x0+18,x1-18],1):
            y=0
            boss=rb(x-16,y-16,3,32,32,12,3)
            boss=boss.cut(hole((0,0,1),(x,y,2),10.5,6.2))
            boss=boss.cut(hole((0,0,1),(x,y,7.9),1.8,8))
            boss=boss.cut(hexshape(x,y,11.8,6.8,3.4))
            body=body.fuse(boss.val()).clean()
            plate=plate.cut(hole((0,0,1),(x,y,.3),10.5,5))
            # The panel retainer flange bridges the pocket at z=7.8. Screw head
            # bears below it at 3.8..7.8; its tip engages the M3 nut at z=11.8.
            flange=cq.Workplane('XY',origin=(x,y,7.8)).circle(11.7).circle(1.8).extrude(1.8)
            neck=cq.Workplane('XY',origin=(x,y,2.7)).circle(11.7).circle(10.5).extrude(5.2)
            # Clear the body for this flange/neck; keep 0.3 mm radial service gap.
            body=body.cut(hole((0,0,1),(x,y,2.9),12,6.7)).clean()
            plate=plate.union(neck).union(flange)
            thumb(f'{i:02}_bottom_thumb_lock_{j}',x,y,3.8,7,True)
            nut(f'{i:02}_bottom_captive_nut_{j}',x,y,11.8)
        # Keep the entire tongue seat open after adding the corner bosses.
        body=body.cut(opening.val()).clean()
        add(f'{i:02}_bottom_panel',plate,(56,65,69))
        bodies[i-1]=(x0,x1,body)
        metadata.append(dict(module=i,panel_clearance_per_side_mm=.35,panel_removal_direction=[0,0,-1],bottom_screw='M3 hand head <=12 mm diameter, 7 mm shaft envelope; select purchased length for full nut engagement',gasket='0.2 mm self-adhesive closed-cell perimeter tape, compressed at the flange; prototype seal fit'))
    # Two small bridge keys sit in the low central valley, outside the hinge
    # mouths and fan outlines. They locate the shells and transfer seam loads.
    # Captive M3 nuts load from the open soles before the panels go on.
    mid=W/2+.15
    for j,y in enumerate([23,45],1):
        bridge=rb(mid-14,y-5,50,28,10,3.3,2)
        for k,x in enumerate([mid-9,mid+9]):
            x0,x1,body=bodies[k]
            boss=rb(x-5,y-5,39.5,10,10,10.5,2)
            boss=boss.cut(hole((0,0,1),(x,y,39),1.8,15))
            # Rear-loaded nut pocket with a ledge above it, accessible through sole.
            boss=boss.cut(hexshape(x,y,39.3,6.8,3))
            body=body.fuse(boss.val()).clean()
            body=body.cut(hole((0,0,1),(x,y,39),1.8,15)).clean()
            bridge=bridge.cut(hole((0,0,1),(x,y,50),1.8,4))
            bodies[k]=(x0,x1,body)
            nut(f'{k+1:02}_bridge_captive_nut_{j}',x,y,39.6)
            thumb(f'{k+1:02}_bridge_thumb_lock_{j}',x,y,53.3,14,False)
        add(f'bridge_key_{j}',bridge,(70,83,86))
    for i,(x0,x1,body) in enumerate(bodies,1):
        add(f'{i:02}_manifold_with_cradle',body)
    return metadata
