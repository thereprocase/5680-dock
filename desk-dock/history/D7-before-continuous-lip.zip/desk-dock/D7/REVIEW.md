# D7 — the plenum is the stand

D7 develops the compact D6 into a cleaner assembly with accessible service parts. The laptop still leans 5° onto the plenum, and the fans still discharge 18° upward from the same 58 mm center datum. The intake remains open and the loading end has no raised tab.

[Open the D7 viewer](../../docs/desk-dock-d7.html). Use **Assembled**, **Fan service**, **Exploded**, **Intake**, and **Plug detail** to inspect the design. Guards and fans have separate visibility controls. Exploded offsets illustrate the components; they do not establish collision-free removal paths.

## What changed and why

- **Fan pockets absorb the frames.** A surrounding rim brings the fan assemblies into the body outline. The fans remain at the D6 position, preserving the small inlet space behind them instead of consuming it to make the exterior appear recessed.
- **Guards also retain the fans.** Front-accessible hand locks release the printed guard and expose the fan. This combines protection and retention in one service part.
- **The ducts can be opened.** Removable bottom panels provide access to the cavities and allow their print orientation to be considered separately from a permanently closed hollow body.
- **The two halves join with keys.** Two hand-fastened bridges sit on the low central deck, keeping clips away from the loading path. The individual plenum cavities remain separate.
- **The plug remains adjustable.** The cassette retains calibration and the independent chassis stop. Hand-operated controls address assembly access without making the connector carry the laptop's stopping load.
- **The surfaces share one purpose.** Graphite structural parts recede visually. Soft contacts remain quiet; restrained green identifies hand controls in the viewer.

## Intended assembly and service

The final component list and geometry determine the exact sequence. The intended workflow is to fit any captive metal hardware while the ducts are open, join the plenum halves, close the bottom panels, seat each fan and retain it with its guard, then fit the soft contacts and calibrate the plug. Fans should be removable from the front without dismantling the laptop support.

With the laptop supported on its end seats, align the plug before setting the separate chassis stop. Confirm full engagement and easy withdrawal on the actual machine. The cap slides toward the cable after its keeper is turned 90° and withdrawn; the keeper is retained when locked and removable when unlocked. See the [cassette assembly notes](CASSETTE_ASSEMBLY.md) for the proposed sequence. The preserved nominal motion slides the laptop 18 mm away from the plug before lifting along its 5° lean. No automatic correction from arbitrary placement angles is claimed.

Tool-free describes the proposed user operation. It does not mean every part is printed: captive nuts, threaded hand fasteners, fans, cables and compliant liners may be purchased parts. Actual thread engagement, finger access, hand force, retention and repeated service still need checking.

## PETG print planning

The target is PETG on a Bambu P1S with a 0.4 mm nozzle. Print the large duct parts and small service parts in orientations appropriate to their load and bridging geometry; do not treat the assembled CAD orientation as a print instruction. Review the hollow shells, fan pockets, guard spans, capture features and first-layer contact in OrcaSlicer before committing to the full set.

Print small fit coupons first for the fan pocket, joining key, captive hardware and panel interfaces. Use those measured fits to tune the model for the actual PETG, nozzle and machine. A nominal CAD clearance is not a measured printer tolerance. The fan model remains a 120 × 120 × 15 mm reference; check the actual frame corners, pads, cable exit and mounting-hole geometry.

OrcaSlicer was not relaunched during this pass after the reported crash. This guide does not claim a sliced, support-free or print-qualified release.

## What the review can establish

The CAD checks can establish solid validity, nominal intersections, designed contact, retained port orientation and the sampled docking path. They do not establish strength, fatigue life, printer fit, stability, fan retention, finger protection, airtightness or thermal performance.

The [D6 airflow study](../D6/AIRFLOW_STUDY.md) records the retained fan position and compact inlet allowance. Its clearance and flow calculations are screening results, not measured cooling or acoustic performance. Recessing the frames does not justify moving the fans farther into the cavity. Recheck any new structure for intrusion into the air aperture.

Before routine use, check:

1. The assembled dock supports the laptop stably, including insertion force, cable pull and desk-edge placement.
2. The laptop contacts only the intended soft seats and lid liners; the underside intake and rubber feet remain clear through the movement.
3. Fans seat without frame distortion, guards clear the rotating blades, and hand locks remain retained after vibration and repeated service.
4. Joining keys, panel interfaces and plug controls are reachable and do not loosen under normal handling.
5. Plug engagement, stop setting, airflow, temperature and sound are acceptable with the actual laptop, fans and printed parts.

The [port study](../D6/PORT_STUDY.md) remains the orientation reference: both Thunderbolt ports are on the keyboard-left end, which appears on the right in a lid-facing view. D7 preserves that handedness.
