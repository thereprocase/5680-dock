"""Small PETG interface coupons for D7; never imports or rebuilds the assembly."""
from pathlib import Path
import hashlib
import json
import math
import cadquery as cq
from cadquery import exporters

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "print"

def box(x,y,z,dx,dy,dz):
    return cq.Workplane("XY").box(dx,dy,dz,centered=False).translate((x,y,z))

def rounded(x,y,z,dx,dy,dz,radius):
    return box(x,y,z,dx,dy,dz).edges("|Z").fillet(radius)

def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    records=[]
    def export(name,part,details):
        shape=part.val() if isinstance(part,cq.Workplane) else part
        assert shape.isValid() and len(shape.Solids())==1 and shape.Volume()>0,name
        b=shape.BoundingBox()
        shape=shape.translate((-b.xmin,-b.ymin,-b.zmin))
        path=OUTPUT/(name+".stl")
        exporters.export(shape,str(path),tolerance=.05,angularTolerance=.1)
        b=shape.BoundingBox()
        records.append({"name":name,"file":path.name,
                        "source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                        "solid_valid":True,"size_mm":[b.xlen,b.ylen,b.zlen],
                        "volume_mm3":shape.Volume(),**details})
        print(path.name,[round(v,2) for v in (b.xlen,b.ylen,b.zlen)],flush=True)

    # cassette.py: cap top at cz+11.7 becomes the bed. Actual 2.7x1.2 mm
    # head and 1.1 mm neck retain their original 0.1 mm overlap.
    male=rounded(0,-4,0,28,8,3,1)
    male=male.union(box(.4,-.55,2.8,27.2,1.1,2))
    male=male.union(box(.4,-1.35,4.7,27.2,2.7,1.2))
    export("COUPON_cap_T_male_2p7_head_1p1_neck",male,
           {"interface":"cap T rail","orientation":"Cap outside face down, matching cap print orientation",
            "fit":"Turn rail downward and slide this same male into each female channel.",
            "support_note":"T-head widens 0.8 mm each side above neck; inspect short overhang after slicing."})
    for gap in (.2,.3,.4):
        # Match production 1.9 mm chamber, 1.3 mm opening and 0.1 mm overlap.
        female=rounded(0,-4,0,24,8,4.9,1)
        female=female.cut(box(-.1,-(2.7+2*gap)/2,2,24.2,2.7+2*gap,1.9))
        female=female.cut(box(-.1,-(1.1+2*gap)/2,3.8,24.2,1.1+2*gap,1.3))
        token=f"{gap:.2f}".replace(".","p")
        export("COUPON_cap_T_female_gap_"+token+"_per_side",female,
               {"interface":"cap T rail","clearance_per_side_mm":gap,
                "production_nominal_clearance_per_side_mm":.35,
                "head_chamber_height_mm":1.9,"orientation":"Coupon base down",
                "support_note":"Two 0.8 mm slot-roof overhangs; inspect short roofs."})

    # body_service.py: R2.65 tongue / R3 opening, offset 0.35 mm per side.
    male=rounded(-3,-3,0,30,30,2.3,3)
    male=male.union(rounded(0,0,2.3,24,24,2.2,2.65))
    export("COUPON_bottom_tongue_male_R2p65",male,
           {"interface":"bottom panel tongue","tongue_height_mm":2.2,
            "tongue_corner_radius_mm":2.65,"orientation":"Panel outside face down",
            "support_note":"Open upward; no enclosed roof."})
    female=rounded(-4.35,-4.35,0,32.7,32.7,3.2,3)
    female=female.cut(rounded(-.35,-.35,-.1,24.7,24.7,3.4,3))
    export("COUPON_bottom_socket_gap_0p35_per_side_R3",female,
           {"interface":"bottom panel tongue","clearance_per_side_mm":.35,
            "opening_corner_radius_mm":3,"orientation":"Flat frame down",
            "limitation":"Cross-section test; main body's fan-face-down layer direction differs.",
            "support_note":"Through opening; no enclosed roof."})

    # Actual rounded pocket corner, shortened in height. R6.5 bore matches
    # modeled R6 fan corner with 0.5 mm radial and side clearance.
    rim=rounded(-64,-64,0,128,128,16,8)
    rim=rim.cut(rounded(-60.5,-60.5,-.1,121,121,16.2,6.5))
    rim=rim.intersect(box(-64,-64,-.1,30,30,16.2))
    export("COUPON_fan_rim_corner_gap_0p50_per_side",rim,
           {"interface":"120 mm fan rim","frame_nominal_mm":120,
            "clearance_per_side_mm":.5,"inner_corner_radius_mm":6.5,
            "modeled_fan_corner_radius_mm":6,"orientation":"Pocket front edge down",
            "fit":"Try directly over one actual fan corner, keeping cable clear.",
            "limitation":"Does not check hole pitch, full-frame bow, axial stack or cable exit.",
            "support_note":"Vertical walls; no enclosed roof."})

    panel=rounded(0,0,0,42,14,4.25,2)
    for x,af in ((7,5.7),(21,5.9),(35,6.1)):
        cavity=cq.Workplane("XY",origin=(x,7,.85)).polygon(6,af/math.cos(math.pi/6)).extrude(3.5)
        panel=panel.cut(cavity)
    # A small edge notch identifies the 5.7 mm end after removing the print.
    marker=cq.Workplane("XY").polyline([(-.1,5.5),(2,7),(-.1,8.5)]).close().extrude(4.5)
    panel=panel.cut(marker)
    export("COUPON_M3_hex_AF_5p7_5p9_6p1_left_to_right",panel,
           {"interface":"M3 hand-knob hex pocket","pocket_AF_mm_left_to_right":[5.7,5.9,6.1],
            "production_nominal_pocket_AF_mm":5.9,"nominal_metal_AF_mm":5.5,
            "floor_mm":.85,"orientation":"Flat back down, open pockets upward",
            "fit":"From the notched end: 5.7, 5.9 and 6.1 mm. Compare actual hardware.",
            "limitation":"Checks across-flats and shallow floor, not nut trap entry or torque.",
            "support_note":"Open pockets; no enclosed roof."})
    report={"revision":"D7","material_target":"PETG / P1S / 0.4 mm nozzle",
            "scope":"Shortened actual interface cross-sections; print and inspect before full bodies.",
            "source_modules_sha256":{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                                      for name in ("cassette.py","body_service.py","fan_service.py")},
            "limitations":["No whole-dock load, warm-creep, airflow or connector-engagement qualification.",
                            "Short coupons omit whole-part warping and full insertion friction.",
                            "Flat socket coupon differs from main-body layer direction."],
            "parts":records}
    (OUTPUT/"coupon-manifest.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")

if __name__=="__main__":main()
