"""Front-service fan pockets for D7; all additions are posed by this module.

The purchased 120 x 120 x 15 mm fan stays at its original datum. Its local
discharge face is z=15 and suction face z=30. The guard rear is z=7.5, so the
original 7.5 mm discharge clearance is preserved. Two diagonal M3 locks use
purchased metal threads; the other two fan holes receive locating pegs.

These are prototype fits, not validated PETG tolerances or finger protection.
"""
import math
import cadquery as cq

SPEC = {
    'pocket_outer_size_mm':128.0,
    'pocket_inner_size_mm':121.0,
    'pocket_local_z_mm':[7.8,30.3],
    'guard_local_z_mm':[4.5,7.5],
    'guard_bar_width_mm':1.6,
    'guard_bar_pitch_mm':9.0,
    'guard_back_to_fan_discharge_mm':7.5,
    'M3_nominal_under_head_length_mm':30.0,
    'hand_knob_height_mm':4.0,
    'fan_locating_peg_diameter_mm':3.8,
    'fan_hole_reference_diameter_mm':4.4,
    'cable_notch_mm':[6.0,4.0],
    'cable_note':'Illustrative upper corner exit; qualify against the actual fan and cable.',
    'nut_retention':'Enclosed hex trap with side-entry porch; slide 10.5 mm toward the fan center, then lift rearward into the open duct for removal.',
    'nut_local_z_mm':[31.8,34.2],
    'thread_note':'Purchased M3 screw and nut; smooth envelopes overlap through the full nominal nut thickness.',
}


def build_fan_service(i,fx,roof,fanpose,box,rb,hole,add):
    """Return a pocket-equipped roof and add the posed service components.

    The caller must not pose these additions again. It remains responsible for
    posing its fan frame, hub and blades. Nut loading porches open into the
    duct; load the enclosed side-entry traps before closing the bottom panel.
    """
    prefix=f'{i:02}_'
    metal=(175,181,185);graphite=(61,69,72);hand=(102,143,132)

    def hexz(x,y,z,af,height):
        return cq.Workplane('XY',origin=(x,y,z)).polygon(6,af/math.cos(math.pi/6)).extrude(height)

    # 0.5 mm nominal space per side around the unchanged fan envelope.
    pocket=rb(fx-64,27,7.8,128,128,22.5,8)
    pocket=pocket.cut(rb(fx-60.5,30.5,7.7,121,121,22.8,6.5))
    # The open rear edge admits the cable; a closed hole would require feeding
    # its connector through the wall. Actual fan wire position is unverified.
    pocket=pocket.cut(box(fx+60.0,140.5,26.3,5,6,4.1))
    roof=roof.union(fanpose(pocket))

    locked=[('A',fx-52.5,38.5),('B',fx+52.5,143.5)]
    located=[(fx+52.5,38.5),(fx-52.5,143.5)]
    # Bosses occupy fan-frame corners, outside the R56.5 air aperture.
    for tag,xx,yy in locked:
        boss=cq.Workplane(obj=hole((0,0,1),(xx,yy,30.1),5.5,5.9))
        roof=roof.union(fanpose(boss))
        # Front and rear walls retain the loose nut along the fan axis. The
        # side-entry porch faces the fan center, outside its air aperture.
        # Load rearward into this porch, then slide toward the frame corner.
        # The nominal M3x30 now engages the full 2.4 mm nut plus 0.3 mm.
        roof=roof.cut(fanpose(hexz(xx,yy,31.6,5.9,2.9)))
        inward=1 if xx<fx else -1
        entry_start=xx-14 if inward<0 else xx
        roof=roof.cut(fanpose(box(entry_start,yy-3.0,31.6,14,6,2.9)))
        roof=roof.cut(fanpose(hole((0,0,1),(xx,yy,29.9),1.7,7)))
        nut=hexz(xx,yy,31.8,5.5,2.4).cut(hole((0,0,1),(xx,yy,31.7),1.3,2.6))
        add(prefix+'fan_captive_nut_'+tag,fanpose(nut),metal,True)
    for xx,yy in located:
        peg=cq.Workplane(obj=hole((0,0,1),(xx,yy,20.4),1.9,12.4))
        # The inherited mounting hole is wider than the locating pin. A rear
        # shoulder bridges that hole and roots the pin into the duct wall.
        peg=peg.union(hole((0,0,1),(xx,yy,30.1),3.5,3.5))
        # Small conical entry assists placement while preserving a flat build.
        peg=peg.union(cq.Solid.makeCone(1.5,1.9,.8,cq.Vector(xx,yy,19.6),cq.Vector(0,0,1)))
        roof=roof.union(fanpose(peg))

    guard=rb(fx-64,27,4.5,128,128,3,8)
    guard=guard.cut(hole((0,0,1),(fx,91,4.4),56.5,3.2))
    # Flat printable bars; each overlaps the surrounding frame at both ends.
    # Print this front face on the bed; stiffness requires PETG test prints.
    for off in range(-54,55,9):
        half=math.sqrt(56.5**2-off**2)+1.2
        guard=guard.union(box(fx-half,91+off-.8,4.5,2*half,1.6,3))
    # Four pads meet the fan's front face. They transfer retention at the frame
    # corners and leave the guard away from the rotating blade envelope.
    for xx in [fx-52.5,fx+52.5]:
        for yy in [38.5,143.5]:
            guard=guard.union(hole((0,0,1),(xx,yy,7.5),4.5,7.5))
    for tag,xx,yy in locked:
        guard=guard.cut(hole((0,0,1),(xx,yy,4.3),1.7,11))
    add(prefix+'fan_guard_retainer',fanpose(guard),graphite)

    for tag,xx,yy in locked:
        # The hex head fits into a printed hand knob; there are no printed
        # load-carrying threads. The nut and shaft show nominal thread overlap.
        screw=hexz(xx,yy,1.5,5.5,3).union(hole((0,0,1),(xx,yy,4.5),1.45,30))
        add(prefix+'fan_M3_screw_envelope_'+tag,fanpose(screw),metal,True)
        knob=cq.Workplane('XY',origin=(xx,yy,.5)).circle(6.5).extrude(4)
        for angle in range(0,360,60):
            a=math.radians(angle)
            knob=knob.cut(hole((0,0,1),(xx+7.6*math.cos(a),yy+7.6*math.sin(a),.4),1.6,4.2))
        knob=knob.cut(hexz(xx,yy,1.35,5.9,3.4))
        add(prefix+'fan_thumb_lock_'+tag,fanpose(knob),hand)
    return roof
