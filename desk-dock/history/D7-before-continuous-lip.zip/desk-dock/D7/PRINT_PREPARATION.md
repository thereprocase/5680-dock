# D7 print preparation — P1S / PETG / 0.4 mm

Use the supplied individual print-oriented parts. The removable sole opens each
plenum for inspection and cleaning. A separate flat fan guard can be printed
face-down and removed for servicing. Do not print the assembled STEP as one part.

The working review profile is **PETG, 0.20 mm layers, five walls, six top and
bottom layers, 20% gyroid infill and an 8 mm outer brim**. The local Generic PETG
profile resolves to 255 °C nozzle, 70 °C textured plate and a 12 mm³/s volumetric
limit. These are profile defaults; use the settings appropriate to the actual
PETG spool for a physical print.

## Placement and supports

The P1S profile has a 256 × 256 mm bed, 250 mm usable height and an 18 × 28 mm
front-left exclusion. `print_check.py` preserves the CAD print orientation,
places each model separately and checks its bounding rectangle plus the complete
8 mm brim against both bed and exclusion. Failure stops preparation; it never
silently rotates, scales or trims a part.

Print flat sole panels and fan guards broad-face down. Print the open plenum
shell with its fan-pocket face down in the supplied orientation; the pocket rim
provides a broad planar bed contact. Opening its bottom avoids trapping support
inside a closed cavity, but does not prove that the body is support-free: inspect
the trunk shoulder, connector shelf, fan-pocket ledges and locking features.
Use accessible supports where those features require them. Check that supports
can be removed through the open bottom or fan opening before committing to a
full body print. Keep bridges crossing the short dimension of slots.

The large body exports are **216.84 × 140.57 × 114.01 mm** and
**201.54 × 140.57 × 114.01 mm**. Both require a careful support review. The sole
panels also have downward-facing roofs inside their recessed thumb-head pockets;
those pockets open from underneath for support removal. Flat guard panels and
hand knobs have no steep downward-facing surfaces above the initial layers in
the geometric screen. This is an angle screen, not a deposited-path result.

Run the fit coupon first. Check the supplied clearance variants by hand, cap
retention, fan-pocket corner fit and latch release. Keep the joint scale at 100%;
adjust the fit parameter rather than scaling the whole dock. PETG clips should
relax after engagement, while broad seating shoulders carry the installed load.

Eight small coupon files are included in `print/`, with their exact dimensions
and limitations in `print/coupon-manifest.json`:

- One cap T tongue and three matching channels with 0.20, 0.30 and 0.40 mm side
  clearance. Production is nominally 0.35 mm; the same male compares all three.
  Retain the small 0.8 mm rail and slot-roof overhangs when judging printed fit.
- A bottom tongue/socket pair preserves the 0.35 mm clearance and R2.65/R3
  corners. The socket coupon prints flat; the final body has a different layer
  direction, so confirm the eventual whole-part fit too.
- A fan-rim corner preserves the modeled 0.5 mm clearance around a 120 mm frame
  with R6 corners. Try the actual fan; this does not check full-frame warping,
  mounting-hole pitch or cable exit.
- An M3 hex panel has 5.7, 5.9 and 6.1 mm across-flat pockets, starting at its
  notched end. The nominal pocket is 5.9 mm. Its 0.85 mm floor also samples the
  shallow fan-knob floor; side-entry nut loading and hand torque remain separate
  checks.

The coupons omit whole-part shrinkage, long sliding friction and warm creep.
Reproduce their geometry with `python desk-dock/D7/export_coupons.py`.

## Local slicer review

The repository defaults to OrcaSlicer. The installed Orca 2.5.0-dev build
58bf267f failed an ordinary `--help` invocation with Windows exception
`0xe06d7363`. It has not been retried. This revision therefore prepares a review
using the already-installed **Bambu Studio** as the explicit fallback. Its one
hidden CLI discovery attempt also failed, exiting with code -2 in 0.71 seconds
without help output. No slice has been claimed from either application. The
current fallback is mesh, plate-fit and overhang-angle screening, while the
prepared slicing runner remains blocked on establishing a working CLI.

The runner resolves installed P1S, process and Generic PETG profiles with their
complete inheritance. It records source hashes and writes flattened copies,
temporary application data and preview artifacts only under `D7/print-review`.
It does not load or change personal slicer preferences, install anything, or
send a print. Slicer processes are hidden and have bounded timeouts.

```text
python desk-dock/D7/print_check.py --prepare
python desk-dock/D7/print_check.py --discover
python desk-dock/D7/print_check.py --preflight desk-dock/D7/print/<part>.stl
python desk-dock/D7/print_check.py desk-dock/D7/print/<part>.stl
```

The discovery result is cached, including failures. The runner will not repeat a
failed discovery or proceed to slicing after one. Supports default to off for a
geometry screen. Use `--supports normal` for a deliberately supported body review;
the recorded report identifies which setting was used.

`--preflight` requires no application launch. It checks watertight meshes, places
them with the brim clearance, and records steep downward-facing surfaces for
inspection. This geometric angle screen does not determine bridge anchoring,
support removal or deposited-path quality.

`profile-evidence.json` records settings and provenance. Each plate gets its
placed geometry, log, plate-fit result and, on success, a `.gcode.3mf` preview
with estimated time and material. These preview archives contain machine-specific
G-code; re-slice with the actual spool settings before any physical print.

Successful slicing establishes that a slicer generated paths. It does not prove
support removal, PETG retention, warm creep, connector fit, structural strength or
physical print success. Final reviewed parts and outcomes are listed in
`print-review/slice-summary.json` once the exported D7 parts have been sliced.

Current geometric review: **all 27 meshes (19 main parts and 8 coupons)** are
watertight and individually fit the P1S with the complete 8 mm brim clear of its
excluded corner. Results and source hashes are in
`print-review/mesh-preflight-summary.json`. They remain unsliced because both
local CLI capability checks failed.
