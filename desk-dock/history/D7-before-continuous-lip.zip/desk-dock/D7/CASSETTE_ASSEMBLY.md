# D7 connector cassette: hand assembly and service

The connector position, 25 mm cable envelope, USB-C shell and nominal adjustment
ranges come from D6. The cassette remains on the keyboard-left end. The complete
station receives the same 5 degree lean as the laptop.

Two hand knobs replace the small underside driver-operated locks. Each printed
knob captures a purchased M3 hex-head screw; two purchased M3 nuts slide into
rear-facing tunnels in the cassette base. The hex pockets prevent nut rotation.
The existing 14 mm washers spread the clamp load over the shelf slots. No printed
threads or heat-set inserts are required.

The cap has two clearance-fit T rails. It slides toward the cable, away from the
laptop, and has a recessed finger scoop. A rigid quarter-turn keeper blocks
sliding while locked. Its lower T lug rotates in an undercut pocket: turn the
finger paddle 90 degrees, lift the keeper out, then slide the cap off. The keeper
is retained when locked and removable when unlocked; it is not a permanently
captive pin. Its release force and resistance to accidental turning require a
physical PETG coupon check.

The independent chassis stop uses a captured M4 nut and a larger hand knob.
The stop limits insertion before force is transferred to the USB-C port. It
must be calibrated to the actual laptop and cable while unloaded.

## Assembly

1. Slide the two M3 nuts into the base from the cable end. Drop the M4 nut into
   its open top pocket and install the stop screw and hand knob.
2. Put the height shim on the shelf. Place the cassette above it. Pass the two
   M3 screws, with their hand knobs and broad washers, upward through the shelf
   slots and shim into the nuts. Leave them loose for calibration.
3. Place the actual cable overmold into the cassette. Drop the 0.8 mm metal front
   clip into its toe slot. Fit compliant lining to suit the measured cable body;
   the envelope alone does not establish a cable clamping fit.
4. Slide the cap toward the laptop. Align the T keeper with the insertion
   keyway, lower it into the cassette and rotate the paddle 90 degrees to lock.
   The cap also traps the front clip against upward removal.
5. Adjust the cassette and the independent soft-tipped chassis stop using the
   actual laptop, with fans off. Tighten the two hand knobs after establishing
   engagement without side load. Confirm repeated docking by hand.

For cable service, unload the laptop, unlock the keeper and slide off the cap.
There is no loading-end projection or tool-access hole through the laptop path.

## Hardware and modeled fit

- Two M3 nuts: 5.5 mm across flats, 2.4 mm height; pockets are 5.9 mm across flats.
- Two M3 hex-head screws: 18 mm nominal length under the head, 5.5 mm head flats.
  The smooth shaft envelope represents the thread major diameter. Each shaft
  passes through an actual clearance bore and its captive nut.
- Two 14 mm outside-diameter M3 washers, 1 mm nominal thickness.
- One M4 nut: 7 mm across flats, 3.2 mm height; pocket is 7.4 mm across flats.
- One M4 stop screw: 21 mm modeled length under the head, with a 7 mm hex head.
  The modeled stop endpoint follows the existing nominal D6 stop position.
- One separate 0.8 mm metal front capture clip. It cannot simply become a thick
  printed shoulder: the measured envelope leaves less than 1 mm at this face.
- Replaceable compliant overmold lining and a soft stop tip, fitted to the real
  hardware. The soft tip currently records its contact envelope; its final
  material and retention method remain to be chosen.

The modeled screw lengths change with height calibration. Select available
metal screw lengths and spacing washers after fitting; the 18 mm M3 and 21 mm
M4 envelopes are geometry, not a claim of verified purchased part numbers.
The M3 nominal nut engagement is its full 2.4 mm thickness, with 1.6 mm shaft
protrusion into a clearance bore. The M4 nominal engagement covers its full
3.2 mm nut thickness. Verify engagement and avoid bottoming at the final setting.

## Print and validation limits

The target is P1S, PETG and a 0.4 mm nozzle. The sliding rails have nominal
0.35 mm clearance per side. The quarter-turn shaft has 0.30 mm radial clearance;
its lug has 0.35 mm clearance to the keyed slot sides. These are initial coupon
dimensions, not guaranteed fits. Check the thin T-rail lips, keeper lug, nut
entry tunnels and finger clearances in OrcaSlicer before printing the cassette.
The keeper should be printed flat on its paddle, with the lug/shaft direction
reviewed for layer strength; repeated handling needs physical testing.

The isolated nominal module has 21 valid single solids with no intersections
between printed parts and hardware envelopes. The cap release path was checked
at 0, 1, 5, 15 and 30 mm withdrawal. Both M3 nut insertion paths were checked at
0, 5, 15 and 20 mm withdrawal. These samples clear the cassette geometry.
The root D7 checks cover the leaned assembly and laptop path separately.
Torque retention, physical cable fit, thumb access, PETG creep and the full
adjustment envelope remain physical qualification items.

The quarter-turn keeper also clears the cassette and cap at 0, 30, 60 and
90 degrees rotation, and at 0, 1, 3, 6, 10 and 15 mm withdrawal after unlocking.
The M4 nut drop-in path clears at 0, 2, 5 and 10 mm above its seated position.
Four combined adjustment corners were screened within this isolated module:
`(depth, lateral, height)` = `(-5,-3,-4)`, `(5,3,5)`, `(-5,3,5)` and
`(5,-3,-4)` mm. Every case has 21 valid single solids and no unintended
printed-part/hardware-envelope intersections. This does not qualify those
settings against the complete laptop or plenum.
