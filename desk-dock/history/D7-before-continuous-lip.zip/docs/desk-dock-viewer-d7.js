import * as THREE from 'three';
import {SoftwareRenderer} from './desk-dock-software.js';
import {OrbitControls} from './vendor/OrbitControls.js';

const $=id=>document.getElementById(id);
const LEAN=5*Math.PI/180, FAN_ANGLE=18*Math.PI/180;
let canvas=$('scene');
const scene=new THREE.Scene();scene.background=new THREE.Color('#182a31');
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true});}
catch{
  const replacement=canvas.cloneNode();canvas.replaceWith(replacement);canvas=replacement;
  renderer=new SoftwareRenderer(canvas);$('air').disabled=true;
  $('air').parentElement.title='Airflow arrows need WebGL. Air enters below the laptop and exits the fans 18° upward.';
}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
const camera=new THREE.PerspectiveCamera(36,1,1,4000);camera.up.set(0,0,1);
const controls=new OrbitControls(camera,canvas);controls.enableDamping=true;
scene.add(new THREE.HemisphereLight(0xeaf8ff,0x344247,2.5));
for(const [position,intensity] of [[[200,400,700],3],[[-400,-200,300],2]]){
  const light=new THREE.DirectionalLight(0xffffff,intensity);light.position.set(...position);scene.add(light);
}
const meshes=[],air=new THREE.Group();scene.add(air);air.visible=false;
const moving=n=>n==='Precision_5680_REFERENCE'||n.startsWith('RUBBER_FOOT_');
const guard=n=>/fan_guard_retainer|outlet_guard|fan_thumb_lock|fan_M3_screw_envelope/.test(n);
const fan=n=>/120x15_fan|fan_frame|fan_hub|blade/.test(n);
const cap=n=>/removable_plug_cap|cassette_cap|plug_cap/.test(n);
const handControl=n=>/thumb|knob|handwheel|hand_lock|quarter_turn_keeper/.test(n);
const nearFar=n=>n.startsWith('01_')?'far end':n.startsWith('02_')?'loading end':'';
function pretty(n){
  const end=nearFar(n),suffix=end?' · '+end:'';
  if(moving(n))return n.startsWith('RUBBER_FOOT_')?'Laptop rubber foot':'Precision 5680 laptop';
  if(n.includes('manifold'))return 'Plenum body'+suffix;
  if(n.includes('fan_guard_retainer'))return 'Removable fan guard'+suffix;
  if(n.includes('fan_thumb_lock'))return 'Fan guard hand lock'+suffix;
  if(n.includes('fan_M3_screw_envelope'))return 'Fan guard M3 screw'+suffix;
  if(n.includes('fan_captive_nut'))return 'Retained fan nut'+suffix;
  if(n.includes('bottom_panel'))return 'Removable duct floor'+suffix;
  if(n.includes('bottom_thumb_lock'))return 'Duct floor hand lock'+suffix;
  if(n.includes('bridge_thumb_lock'))return 'Body joining hand lock'+suffix;
  if(n.includes('bridge_key'))return 'Body joining key';
  if(n.includes('plug_cap_quarter_turn_keeper'))return 'Plug cap quarter-turn keeper';
  if(cap(n))return 'Sliding plug cassette cap';
  if(n.includes('cassette_thumb_knob'))return 'Cassette hand lock';
  if(n.includes('stop_thumb_knob'))return 'Chassis stop hand control';
  if(n.includes('X_depth_overmold_clamp'))return 'Plug cassette body';
  if(n.includes('height_shim_pack'))return 'Plug height shim';
  if(n.includes('fan_frame'))return '120 × 15 mm fan'+suffix;
  if(n.includes('fan_hub'))return 'Fan hub'+suffix;
  if(n.includes('blade'))return 'Fan blade'+suffix;
  if(n.includes('lid_bearing'))return 'Soft lid contact';
  if(n.includes('corner_pad'))return 'Soft end seat';
  if(n.includes('hinge_seal'))return 'Exhaust seal';
  if(n.includes('foot_'))return 'Desk grip pad'+suffix;
  return n.replace(/^\d+_/,'').replace(/_REFERENCE/g,'').replaceAll('_',' ').replace(/\b\w/,s=>s.toUpperCase());
}
function partColor(p){
  const n=p.name;
  if(handControl(n))return [102,143,132];
  if(p.reference||fan(n))return p.color;
  if(/liner|corner_pad|seal|soft_tip/.test(n))return [106,120,111];
  if(n.includes('foot_'))return [34,40,41];
  if(/nut|washer|metal/.test(n))return p.color;
  return [61,69,72];
}
let playing=false,start=0,selected=null,viewMode='home';
const hints={
  home:'The lid rests on the plenum. Fans sit inside its front pockets.',
  service:'Guards and their hand locks are hidden. The fan frames remain seated in the body pockets.',
  exploded:'Inspect the guards, fans, duct floors and joining keys. These offsets show the parts, not a tested assembly sequence.',
  under:'The intake side stays open. The low contacts touch the bare case margins and leave the rubber feet clear.',
  plug:'The cap is hidden to expose the plug cassette. Align it before setting the separate chassis stop.'
};
function stop(){playing=false;$('play').textContent='Play docking motion';$('play').setAttribute('aria-pressed','false');}
function offset(p){
  const n=p.name,s=p.center[0]>177?1:-1;
  if(moving(n))return [18,Math.sin(LEAN)*145,Math.cos(LEAN)*145];
  if(n.includes('manifold'))return [s*54,0,0];
  if(n.includes('bridge_key'))return [0,0,55];
  if(n.includes('bridge_thumb_lock'))return [0,0,80];
  if(n.includes('bridge_captive_nut'))return [s*54,0,12];
  if(n.includes('bottom_panel'))return [s*54,0,-60];
  if(n.includes('bottom_thumb_lock'))return [s*54,0,-85];
  if(n.includes('bottom_captive_nut'))return [s*54,0,-16];
  if(n.includes('foot_'))return [s*54,0,-85];
  if(guard(n))return [s*54,135,45];
  if(n.includes('fan_captive_nut'))return [s*54,40,-5];
  if(fan(n))return [s*54,70,23];
  if(n.includes('quarter_turn_keeper'))return [-54,0,60];
  if(cap(n))return [-78,0,8];
  if(n.includes('lid_bearing'))return [s*54,-28,0];
  if(/seal|corner_pad/.test(n))return [s*54,0,35];
  return [-65,0,30];
}
function update(){
  const e=+$('explode').value/100,t=+$('motion').value/100;
  const lift=Math.max(0,(t-.2)/.8)*135,x=18*Math.min(1,t/.2);
  $('explodeValue').textContent=Math.round(e*100)+'%';
  $('motionValue').textContent=t===0?'Seated':lift>0?Math.round(lift)+' mm lift':x.toFixed(1)+' mm slide';
  const serviceLabel=!$('guards').checked?($('fans').checked?'Guards removed · fans seated in pockets':'Fans removed · pockets exposed'):'Fans enclosed in the plenum pockets';
  $('state').textContent=e>0?'Exploded assembly':lift>0?'Lift / lower onto the end seats':t>0?'Slide clear of the far-side plug':viewMode==='service'?serviceLabel:viewMode==='plug'&&!$('cover').checked?'Plug cap removed':'Docked · lid toward you';
  if(viewMode==='service')$('viewHint').textContent=$('guards').checked?'Front access to the guards and their hand locks. Hide the guards to inspect the fan seating.':$('fans').checked?hints.service:'Fans, guards and hand locks are hidden. The pocket walls and corner locating features are exposed.';
  if(viewMode==='plug')$('viewHint').textContent=$('cover').checked?'The cap captures the original plug. Hide it to inspect the cassette and independent chassis stop.':hints.plug;
  for(const mesh of meshes){
    const p=mesh.userData;mesh.position.set(...p.explode).multiplyScalar(e);
    if(moving(p.name)&&!e)mesh.position.set(x,Math.sin(LEAN)*lift,Math.cos(LEAN)*lift);
    mesh.visible=(!moving(p.name)||$('laptop').checked)&&(!cap(p.name)||$('cover').checked)&&(!guard(p.name)||$('guards').checked)&&(!fan(p.name)||$('fans').checked);
  }
  air.visible=$('air').checked&&e===0;
}
function pointCamera(name,includeMotion=false){
  const stageRect=canvas.parentElement.getBoundingClientRect();
  camera.aspect=stageRect.width/stageRect.height;camera.updateProjectionMatrix();
  const views={
    home:[[-300,800,470],[170,35,145]],
    service:[[177,535,155],[177,49,76]],
    exploded:[[-410,950,480],[170,55,130]],
    under:[[100,-880,370],[177,0,140]],
    plug:[[-185,165,165],[-12,3,115]]
  };
  const [position,target]=views[name];camera.position.set(...position);controls.target.set(...target);
  if(name!=='plug'&&meshes.length){
    scene.updateMatrixWorld(true);
    const bounds=new THREE.Box3();
    for(const mesh of meshes)if(mesh.visible){
      bounds.expandByObject(mesh);
      if(includeMotion&&moving(mesh.userData.name)){
        mesh.geometry.computeBoundingBox();
        bounds.union(mesh.geometry.boundingBox.clone().translate(new THREE.Vector3(18,Math.sin(LEAN)*135,Math.cos(LEAN)*135)));
      }
    }
    const center=bounds.getCenter(new THREE.Vector3()),forward=new THREE.Vector3(...target).sub(new THREE.Vector3(...position)).normalize();
    const right=new THREE.Vector3().crossVectors(forward,camera.up).normalize(),up=new THREE.Vector3().crossVectors(right,forward).normalize();
    const vertical=Math.tan(camera.fov*Math.PI/360),horizontal=vertical*camera.aspect;
    let distance=100;
    for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){
      const rel=new THREE.Vector3(x,y,z).sub(center),depth=rel.dot(forward);
      distance=Math.max(distance,1.2*Math.abs(rel.dot(right))/horizontal-depth,1.2*Math.abs(rel.dot(up))/vertical-depth);
    }
    controls.target.copy(center);camera.position.copy(center).addScaledVector(forward,-distance);
  }
  controls.update();
}
function setView(name){
  stop();viewMode=name;$('explode').value=name==='exploded'?65:0;$('motion').value=0;
  for(const id of ['laptop','cover','fans','guards'])$(id).checked=true;
  $('air').checked=false;
  if(name==='service'){$('guards').checked=false;$('laptop').checked=false;}
  if(name==='exploded')$('laptop').checked=false;
  if(name==='plug')$('cover').checked=false;
  $('viewHint').textContent=hints[name];
  document.querySelectorAll('[data-view]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.view===name)));
  update();pointCamera(name);
}
function describe(n){
  if(moving(n))return 'Laptop reference. Both Thunderbolt ports are on the keyboard-left edge, at the far plug end. The rubber feet remain outside the intended bearing contacts.';
  if(n.includes('manifold'))return 'Collects exhaust and supports the lid through soft liners. The fan frame sits within the front pocket; the underside intake stays open.';
  if(n.includes('fan_guard_retainer'))return 'The front guard also retains the fan. Release its hand locks for service. The proposed guard and retention need physical fit and finger-clearance checks.';
  if(n.includes('fan_thumb_lock'))return 'Turn by hand to release the fan guard. Retention, reach and clamp force need prototype checks.';
  if(n.includes('fan_captive_nut'))return 'An enclosed side-entry trap keeps the nut from falling rearward when the guard screw is removed. Its loading porch is accessible through the open duct floor.';
  if(n.includes('bottom_panel'))return 'Removable duct floor gives access to the cavity and avoids printing a permanently closed duct. Check the joint fit and leakage in the prototype.';
  if(n.includes('bridge_key'))return 'Hand-fastened bridge on the low central deck joins the two plenum halves. Check hand access and retention before loading the stand.';
  if(fan(n))return '120 × 15 mm fan reference. Fan centers remain at the D6 position, with discharge 18° above the desk. The exact purchased fan must be checked against the pocket.';
  if(n.includes('plug_cap_quarter_turn_keeper'))return 'Rotate 90° to align the keyway, then lift the keeper and slide the cap toward the cable. It is retained while locked and removable while unlocked.';
  if(cap(n))return 'Slide the cap toward the cable after releasing the quarter-turn keeper. The cassette holds the original Dell plug; physical connector calibration is still required.';
  if(n.includes('stop'))return 'Independent chassis stop limits insertion travel so the connector does not carry the seating load. Set it after aligning the plug.';
  if(/shim/.test(n))return 'Sets the connector height. Select the stack during physical plug alignment.';
  if(/cassette|overmold_clamp/.test(n))return 'Plug capture and calibration assembly. Adjust height, lateral position and insertion depth before setting the chassis stop.';
  if(n.includes('lid_bearing'))return 'Replaceable soft contact between the lid and the plenum. The shell carries the lean load.';
  if(/corner_pad/.test(n))return 'Soft profiled end seat carries the laptop case at its bare end margin.';
  if(n.includes('seal'))return 'Compliant exhaust seal. It seals airflow; the end seats carry the laptop weight.';
  if(n.includes('foot_'))return 'Soft desk grip pad. Test sliding and tip stability with the actual laptop and cable loads.';
  if(handControl(n))return 'Hand-operated fastener for assembly or calibration. Physical access and retention require prototype checks.';
  return 'D7 assembly component. See the design guide for assembly, fit and print-planning limits.';
}
function select(mesh){
  if(selected)selected.material.emissive.setHex(0);selected=mesh;
  if(mesh){mesh.material.emissive.setHex(0x235549);$('part').value=mesh.userData.name;$('detail').textContent=pretty(mesh.userData.name)+'. '+describe(mesh.userData.name);}
  else{$('part').value='';$('detail').textContent='Select a part in the model or the list to see what it does.';}
}
try{
  const [manifest,buffer]=await Promise.all([
    fetch('models/desk-dock-d7/model.json').then(r=>{if(!r.ok)throw Error(r.status);return r.json();}),
    fetch('models/desk-dock-d7/model.bin').then(r=>{if(!r.ok)throw Error(r.status);return r.arrayBuffer();})
  ]);
  for(const p of manifest.parts){
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(buffer,p.positionOffset,p.vertexCount*3),3));
    geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(buffer,p.indexOffset,p.indexCount),1));geometry.computeVertexNormals();
    const material=new THREE.MeshStandardMaterial({color:new THREE.Color(...partColor(p).map(v=>v/255)).convertSRGBToLinear(),roughness:.76,metalness:p.reference ? .2 : .04,flatShading:true});
    const mesh=new THREE.Mesh(geometry,material);mesh.userData={...p,explode:offset(p)};scene.add(mesh);meshes.push(mesh);
    const option=document.createElement('option');option.value=p.name;option.textContent=pretty(p.name);$('part').append(option);
  }
  // Direction arrows only: no CFD or measured-flow claim.
  for(const x of [84,269.68]){
    air.add(new THREE.ArrowHelper(new THREE.Vector3(0,Math.cos(FAN_ANGLE),Math.sin(FAN_ANGLE)),new THREE.Vector3(x,76,76),75,0x79decd,12,7));
    air.add(new THREE.ArrowHelper(new THREE.Vector3(0,1,0),new THREE.Vector3(x,-82,128),55,0x80c8ff,10,6));
    air.add(new THREE.ArrowHelper(new THREE.Vector3(0,0,-1),new THREE.Vector3(x,0,72),32,0xf3b76d,8,5));
  }
  $('loading').hidden=true;window.deskDockReady=true;setView('home');
}catch(error){$('loading').textContent='The D7 CAD could not be loaded. Use the local viewer launcher and reload.';console.error(error);}
for(const id of ['explode','motion'])$(id).addEventListener('input',()=>{
  const requested=$(id).value;
  if(id==='motion'&&viewMode!=='home'){setView('home');$('motion').value=requested;}
  if(id==='explode'&&+requested>0&&viewMode!=='exploded'){setView('exploded');$('explode').value=requested;}
  stop();$(id==='explode'?'motion':'explode').value=0;
  if(id==='motion')$('laptop').checked=true;
  update();
  if(id==='motion')pointCamera('home',true);
});
for(const id of ['laptop','cover','fans','guards','air'])$(id).addEventListener('change',update);
document.querySelectorAll('[data-view]').forEach(button=>button.onclick=()=>setView(button.dataset.view));
$('part').onchange=()=>select(meshes.find(mesh=>mesh.userData.name===$('part').value));
$('reset').onclick=()=>{select(null);setView('home');};
$('play').onclick=()=>{
  if(playing){stop();return;}
  setView('home');pointCamera('home',true);playing=true;start=performance.now();$('play').textContent='Pause docking motion';$('play').setAttribute('aria-pressed','true');
};
let down;
canvas.addEventListener('pointerdown',event=>down=[event.clientX,event.clientY]);
canvas.addEventListener('pointerup',event=>{
  if(!down||Math.hypot(event.clientX-down[0],event.clientY-down[1])>5)return;
  const rect=canvas.getBoundingClientRect(),ray=new THREE.Raycaster();
  ray.setFromCamera(new THREE.Vector2((event.clientX-rect.left)/rect.width*2-1,1-(event.clientY-rect.top)/rect.height*2),camera);
  const hit=ray.intersectObjects(meshes.filter(mesh=>mesh.visible))[0];if(hit)select(hit.object);
});
canvas.addEventListener('keydown',event=>{if(event.key==='Escape'){stop();select(null);}});
new ResizeObserver(()=>{
  const rect=canvas.parentElement.getBoundingClientRect();renderer.setSize(rect.width,rect.height,false);camera.aspect=rect.width/rect.height;camera.updateProjectionMatrix();
}).observe(canvas.parentElement);
function frame(now){
  requestAnimationFrame(frame);
  if(playing){const q=((now-start)/1000)%10,t=q<4?q/4:q<5?1:q<9?1-(q-5)/4:0;$('motion').value=t*100;update();}
  controls.update();renderer.render(scene,camera);
}
requestAnimationFrame(frame);
window.deskDockState=()=>({revision:'D7',parts:meshes.length,visible:meshes.filter(m=>m.visible).length,explosion:+$('explode').value,motion:+$('motion').value,view:viewMode,playing,guardsVisible:meshes.filter(m=>guard(m.userData.name)&&m.visible).length,fansVisible:meshes.filter(m=>fan(m.userData.name)&&m.visible).length,positions:meshes.filter(m=>moving(m.userData.name)).map(m=>m.position.toArray())});
window.deskDockOrientation=()=>{
  const c=new THREE.PerspectiveCamera(36,1,1,4000);c.up.set(0,0,1);c.position.set(177,930,240);c.lookAt(177,30,155);c.updateMatrixWorld();
  const left=new THREE.Vector3(0,0,120).project(c),right=new THREE.Vector3(353.68,0,120).project(c);
  return {revision:'D7',keyboardLeftScreenX:left.x,keyboardRightScreenX:right.x,keyboardLeftAppearsOnRight:left.x>right.x,withdrawalX:18,laptopLeanDeg:5,fanDischargeDeg:18};
};
